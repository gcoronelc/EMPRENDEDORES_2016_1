package pe.egcc.appedutec;

import pe.egcc.appedutec.view.FormularioMDI;

/**
 *
 * @author Gustavo Coronel
 * @blog www.desarrollasoftware.com
 * @email gcoronelc@gmail.com
 */
public class ClasePrincipal {

  public static void main(String[] args) {
    FormularioMDI.main(args);
  }
  
}
